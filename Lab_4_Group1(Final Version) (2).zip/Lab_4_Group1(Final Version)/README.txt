Lab 4 general description
1. The URL: https://www.youtube.com/watch?v=NW569p_ZVis&t=2s
2. There are 3 screen shots for the block diagram, 1 screen shot for the front panel.
3. Two trained weights are presented in the "Trained Weights" folder as "weight0-Trained1.csv" and "weight1-Trained1.csv", you can try it if you like
4. Two randomed weights are presented in the main folder as "weight0.csv" and "weight1.csv" (you should use this one to start)

How to run and test
1. To run the program, first connect the brick, then open \Lab4\A3.lvproj.
2. After the project is open, open the load_from_file.vi from the My Computer Directory, then run it.
3. After the dialog comes out, select in order  of : weights0.csv, weight1.csv, input_data_modifired.csv, targets.csv
4. Now go to A4.vi, fill in 10000 and 0.06 as trained cycle and alpha value (the fillinf area should be at top right above graphs)
5. Run the A4.vi and wait until it stops by itself. it will generate the "W0New" and "W1New" (it is automatically saved, you do not need to reload anything)
6. Now run A3.vi and you may see that the weights used in A3.vi is just the one you generated (you can compared it to make sure), because it is automatically saved
7. Now you may use the weighs you just generated to test LEDs

Collaborator(s): Ringgold Lin, James Fuh

Thank you for reading