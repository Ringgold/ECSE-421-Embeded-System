1. The URL: https://www.youtube.com/watch?v=xrrrcY5heLk
2. Screen shots were included as shown
3. The switch is the controller of the filter, slide to right to turn off
4. The number input is the cutoff value of lowpass filter, 0.05 or 0.06 is good
5. To open the file, don't open vi file directly, should connect you board, then open the project file, then choose the vi file inside the labview file menu

Collaborator(s): Ringgold Lin, James Fuh

Thank you for reading