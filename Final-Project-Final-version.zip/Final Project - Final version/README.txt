Video: https://youtu.be/wVcjBzjWTtc
The "Final Project" folder containes everything:
1. "0 to 9 input on table" is the data set we selected to train
2. "0 to 9 target 10 each" is the corresponding target file
3. "on table w0" is the w0 weight we trained and used on the demo
4. "on table w1" is the w1 weight we trained and used on the demo
5. "weight0" is the randomized weight0
6. "weight1" is the randimized weight1

(Always connect the board before anything)
Firstly, in the training control, set hidden layer = 1
				# nodes per hidden layer = 8
				# inputs = 200
				# outputs = 10

Data Collection (Go to the Data Generation Control in lab4.vi):
1. Set Filter ON, Write Data ON
2. Set "# of Samples to collect" to be 100
3. Set the target value to be the integer you plan to draw
4. At main control, switch mode to be "data_collection"
5. Run the lab4.vi
6. Draw a number by pressing "next target", you have to draw it within 2 seconds
7. If you want to draw again (collect another sample), you need to stop the program then run it again
8. The first data sample will not show on the table until you draw the second one. (if you want to collect 10 samples, simply draw it for 11 times)
9. Export the collected data (stop the program, go to the data table, right click, export to an excel and save it)

Training Your Weights (in this case I will use my files as example, you can generate for yourself if you want)
1. Load the file in an other of: "weight0", "weight1", "0 to 9 input on table","0 to 9 target 10 each"
				randomized weights file		input data to train	output
2. Set Data Source ON. Write WEIGHTS ON, Activation OFF
3. Learning rate = 0.01, validation split = 0.2
4. Switch the mode in the Main Control to be "network_train"
5. Run program, press Start Training Botton to start the train
6. Usually I wait until the Mean Square Erro reach 0.13~0.14 to stop, where the erro hardly goes down any more
7. Click stop training when it is done
8. Go to the save_to_file.vi
9. run the program and save 4 times to 4 seperate files: the last 2 files are "trained weight 0" and "trained weight 1" respectively

Inference
1. Load file in the following order: "on table w0", "on table w1", "0 to 9 input on table", "0 to 9 target 10 each"
					My trained weights		these last 2 files can be any files
2. Switch the Main Control to be "inferece"
3. Set Weights Source to be ON so that you are using the weights you just loaded
4. Run the program
5. Click Start Inference to draw you number
	a. Each number has to be drawn with in 2 seconds
	b. Draw it on the table for the best effect
	c. The result will be shown on the big max index
		0: a counter clock-wise circle
		1: a line from top to bottom, it has to be drawn within 70 samples count
		2: need to clearly indicate the upper curve or it is going to be treated as 4
		3: Not too fase
		4: Should not have any problem
		5: As long as the left top "Corner" is clear, there should be no problem
		6: As long as it is large enough, and the final curve is slow enough, there should be no problem
		7: Should not have any problem
		8: As long as it is large enough, and was done in 2 seconds, should be no problem
		9: Should not have any problem
6. To draw another number, simply click "Start Inference" again to draw it
7. Look at the "Sample Count" to check you progress of one individual draw
8. Look at the video for a more detaile and visual way of how to draw it   


