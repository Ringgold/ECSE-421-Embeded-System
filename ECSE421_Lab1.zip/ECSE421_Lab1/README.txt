https://youtu.be/-KIrCjoVCUw
1. The above is the location of the 18s video
2. Go to Files > A1.vi to open the project
3. In case to waste you cpu, you may want to set timer to be 200 (on the right)
4. The greem light shows if you can take the soda (0.25), and will reset everything afterwards
5. Click the Nickel, Dime, and Quarter button to add money
6. If you deposited over or equal to 25 cents, you will not be able to deposit any more
7. If you have over 25 cents deposited, before you take soda, you can see how much you can get back
8. Thank you for reading!

