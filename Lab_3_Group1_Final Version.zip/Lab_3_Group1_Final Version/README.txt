Lab 3 general description
1. The URL: https://www.youtube.com/watch?v=5fItE_O6F14
2. There are 2 screen shots for the block diagram, 1 screen shot for the front panel.
3. The switch is the controller of the filter, slide to right to turn off.
4. The number input above the filter switch is the cutoff value of lowpass filter, 0.05 or 0.06 is good.

How to run and test
1. To run the program, first connect the brick, then open \Lab3\A3.lvproj.
2. After the project is open, open the load_from_file.vi from the My Computer Directory, then run it.
3. After the dialog comes out, first select the weights_input_h0.csv, then select weights_h0_out.csv (all in the main folder). 
4. Notice: make sure the "# hidden layers" in the load_from_file.vi is integer "1"
5. Now go to A3.vi to run the program, and you would be able to see the overall project with 5 inputs, 8 hidden layers, and 3 outputs all monitored.
6. The part that Lab 3 is involved is located at the right part of the front panel. Same thing goes with the block diagram. 

Collaborator(s): Ringgold Lin, James Fuh

Thank you for reading